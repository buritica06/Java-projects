//perimetro P = 2· a + 2· b
// area = a*b
// Hipotenusa
package rectangulo;

/**
 *
 * @author estudiante
 */
public class Rectangulo {
    
    
 private double lado1;
 private double lado2;
public Rectangulo (){} // constructor por defecto
public Rectangulo (double lado1,double lado2){ //constructor alternativo
    this.lado1 =lado1;
    this.lado2 =lado2;
}
public void setLado (double lado1,double lado2){ // metodo modificador
    this.lado1 =lado1;
    this.lado2 =lado2;
}
public double getArea(){// metodo analizador
 return lado1*lado2;
}
// demas metodos
public double getPerimetro(){ 
return (2*lado1)+(2*lado2);
}
public double getHiponetusa(){
return Math.sqrt((Math.pow(lado1,2)+(Math.pow(lado2,2))));
}
  
        
}
